import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import ResearcherDashboard from './components/reports/SearchSignature/ResearcherDashboard'
import SearchSignature from './components/reports/SearchSignature/SearchSignature'
function App() {
  return (
    <ResearcherDashboard/>
  );
}

export default App;
