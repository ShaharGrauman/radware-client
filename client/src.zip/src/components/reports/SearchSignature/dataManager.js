export const constants={
    attackType:['one','two','three','aysfd'],
    status:['In progress', 'In test','In QA','Published','Suspended'],
    reference:['one','two','three']
}

